Elomi HIV Epidemiology Dashboard (PostgreSQL Version)

Instructions:
1. Upload all files into /public_html/epi_Dashboard/
2. Edit config.php with your actual PostgreSQL DB username and password.
3. Ensure your PostgreSQL database contains the correct schema (use the provided .sql file).
4. Visit:
   - upload.php to upload HIV CSV data
   - view.php to browse and visualize uploaded data

Support: Yimam, Elomi Health Research and Training
